//
//  postCell.swift
//  zg268_p5
//
//  Created by Zhongyi (James) Guo on 4/7/22.
//

import Foundation

import UIKit

class PostCellController: UITableViewCell {
    
    var id = UILabel()
    var title = UILabel()
    var body = UITextView()
    var poster = UILabel()
    var timeStamp = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .systemBackground
        selectionStyle = .default
        
        id.font = .systemFont(ofSize: 10, weight: .light)
        id.textColor = .darkGray
        id.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(id)
        
        title.font = .systemFont(ofSize: 17, weight: .bold)
        title.textColor = .systemMint
        title.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(title)

        body.font = .systemFont(ofSize: 12)
        body.textColor = .gray
        body.isScrollEnabled = true
        body.isEditable = false
        body.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(body)
        
        poster.font = .systemFont(ofSize: 15)
        poster.textColor = .systemMint
        poster.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(poster)
        
        timeStamp.font = .systemFont(ofSize: 12)
        timeStamp.textColor = .lightGray
        timeStamp.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(timeStamp)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            id.topAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.topAnchor, constant: 3),
            id.leadingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.leadingAnchor, constant: 15),
            id.trailingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.trailingAnchor, constant: -15)
        ])
        
        NSLayoutConstraint.activate([
            title.topAnchor.constraint(equalTo: id.bottomAnchor, constant: 3),
            title.leadingAnchor.constraint(equalTo: id.leadingAnchor),
            title.trailingAnchor.constraint(equalTo: id.trailingAnchor)
        ])
        
        NSLayoutConstraint.activate([
            body.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 3),
            body.heightAnchor.constraint(equalToConstant: 84),
            body.leadingAnchor.constraint(equalTo: id.leadingAnchor),
            body.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -15)
        ])
        
        NSLayoutConstraint.activate([
            poster.topAnchor.constraint(equalTo: body.bottomAnchor, constant: 3),
            poster.heightAnchor.constraint(equalToConstant: 20),
            poster.leadingAnchor.constraint(equalTo: id.leadingAnchor),
            poster.bottomAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.bottomAnchor, constant: -5)
        ])
        
        NSLayoutConstraint.activate([
            timeStamp.heightAnchor.constraint(equalToConstant: 20),
            timeStamp.centerYAnchor.constraint(equalTo: poster.centerYAnchor),
            timeStamp.trailingAnchor.constraint(equalTo: contentView.safeAreaLayoutGuide.trailingAnchor, constant: -5)
        ])
    }
    
    func configure(post: Model) {
        id.text = post.id?.uuidString
        title.text = post.title
        body.text = post.body
        poster.text = post.poster
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy HH:mm"
        dateFormatter.timeZone = NSTimeZone(abbreviation: "EST") as TimeZone?
        let temp = post.timeStamp?.description
        let temp_new = temp?.dropLast(6)
        timeStamp.text = String(temp_new!)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
