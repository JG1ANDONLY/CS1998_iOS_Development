//
//  UpdatePostController.swift
//  zg268_p5
//
//  Created by Zhongyi (James) Guo on 4/10/22.
//

import Foundation
import UIKit


protocol UpdatePostDelegate {
    func updatePost(id: String?, title: String?, body: String?, poster: String?)
}

class UpdatePostController: UIViewController {
    
    var delegate: UpdatePostDelegate?
    var id: String?
//    var parentController: UIViewController?
    var titleLabel = UILabel()
    var bodyLabel = UILabel()
    var posterLabel = UILabel()
    
    var titleField = UITextView()
    var bodyField = UITextView()
    var posterField = UITextView()
    
    var updatePost = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        self.navigationController?.navigationBar.tintColor = .systemMint
        self.navigationController?.navigationBar.prefersLargeTitles = false
        self.navigationItem.title = "Update"
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(handleCancel))
        
        titleLabel.text = "Title:"
        titleLabel.font = titleLabel.font.withSize(20)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)
        
        titleField.font = titleField.font?.withSize(17)
        titleField.isEditable = true
        titleField.layer.borderColor = UIColor.lightGray.cgColor
        titleField.layer.borderWidth = 1
        titleField.layer.cornerRadius = 5
        titleField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleField)
        
        bodyLabel.text = "Content:"
        bodyLabel.font = bodyLabel.font.withSize(20)
        bodyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bodyLabel)
        
        bodyField.becomeFirstResponder()
        bodyField.isEditable = true
        bodyField.font = bodyField.font?.withSize(17)
        bodyField.layer.borderColor = UIColor.lightGray.cgColor
        bodyField.layer.borderWidth = 1
        bodyField.layer.cornerRadius = 5
        bodyField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bodyField)
        
        posterLabel.text = "Poster:"
        posterLabel.font = posterLabel.font.withSize(20)
        posterLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(posterLabel)
        
        posterField.isEditable = true
        posterField.font = posterField.font?.withSize(17)
        posterField.layer.borderColor = UIColor.lightGray.cgColor
        posterField.layer.borderWidth = 1
        posterField.layer.cornerRadius = 5
        posterField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(posterField)
        
        updatePost.setTitle("Update", for: .normal)
        updatePost.titleLabel?.font = updatePost.titleLabel?.font.withSize(20)
        updatePost.titleLabel?.textAlignment = .center
        updatePost.backgroundColor = .systemMint
        updatePost.layer.cornerRadius = 15
        updatePost.tintColor = .systemBackground
        updatePost.addTarget(self, action: #selector(update), for: .touchUpInside)
        updatePost.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(updatePost)
        setupConstraints()
        
        
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            titleField.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            titleField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            titleField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            titleField.heightAnchor.constraint(equalToConstant: 38)
        ])
        
        NSLayoutConstraint.activate([
            bodyLabel.topAnchor.constraint(equalTo: titleField.bottomAnchor, constant: 10),
            bodyLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            bodyField.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 10),
            bodyField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            bodyField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            bodyField.heightAnchor.constraint(equalToConstant: 200)
        ])
        
        NSLayoutConstraint.activate([
            posterLabel.topAnchor.constraint(equalTo: bodyField.bottomAnchor, constant: 10),
            posterLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            posterField.topAnchor.constraint(equalTo: posterLabel.bottomAnchor, constant: 10),
            posterField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            posterField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            posterField.heightAnchor.constraint(equalToConstant: 38)
        ])
        
        NSLayoutConstraint.activate([
            updatePost.topAnchor.constraint(equalTo: posterField.bottomAnchor, constant: 20),
            updatePost.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            updatePost.widthAnchor.constraint(equalToConstant: 200),
            updatePost.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    @objc func handleCancel() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func update() {
        UIView.animate(withDuration: 0.1, animations: {self.updatePost.transform = CGAffineTransform(scaleX: 0.85, y: 0.85)}, completion: { _ in UIView.animate(withDuration: 0.1) {self.updatePost.transform = CGAffineTransform.identity}})
        
        if titleField.text! == "" {
            let alert = UIAlertController(title: "Invalid Title", message: "Please enter your title.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else if bodyField.text! == "" {
            let alert = UIAlertController(title: "Invalid Content", message: "Please enter your content.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else if posterField.text! == "" {
            let alert = UIAlertController(title: "Invalid Poster", message: "Please enter your poster name.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else {
            delegate?.updatePost(id:id, title: titleField.text!, body: bodyField.text!, poster: posterField.text!)
            let alert = UIAlertController(title: nil, message: "Updated!", preferredStyle: .alert)
            present(alert, animated: true, completion: nil)
            dismiss(animated: true, completion: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
}

