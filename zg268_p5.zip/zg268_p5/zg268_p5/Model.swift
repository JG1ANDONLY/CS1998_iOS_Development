//
//  Models.swift
//  zg268_p5
//
//  Created by Zhongyi (James) Guo on 4/8/22.
//

import Foundation

class Model: Codable {
    var id: UUID?
    var title: String?
    var body: String?
    var poster: String?
    var timeStamp: Date?
    
    init(title: String, body: String, poster: String) {
        self.id = UUID()
        self.title = title
        self.body = body
        self.poster = poster
        self.timeStamp = Date()
    }
}
