//
//  ViewController.swift
//  zg268_p5
//
//  Created by Zhongyi (James) Guo on 4/6/22.
//

import UIKit
import SwiftUI

class ViewController: UIViewController {
    
    
    var postTable = UITableView()
    var posts: [Model] = []
    var reuseIdentifier = "reuseIdentifier"
    var createPostsbutton: UIBarButtonItem?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .systemBackground
        self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.title = "Posts"
        
        let post1 = Model(title: "To User", body: "Please pull down to refresh the page! (I did not implement GET from database, but the user interaction experience is here.", poster: "James Guo")
        let post2 = Model(title: "To User", body: "Please use the plus sign on the right of the navigation bar to create a new post!", poster: "James Guo")
        let post3 = Model(title: "To User", body: "Please swipe lefe to delete post(s)!", poster: "James Guo")
        let post4 = Model(title: "To User", body: "Please click on the cell to update the cell!", poster: "James Guo")
        posts = [post1, post2, post3, post4]
        
        postTable.dataSource = self
        postTable.delegate = self
        postTable.translatesAutoresizingMaskIntoConstraints = false
        postTable.register(PostCellController.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(postTable)
        
        createPostsbutton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(createPost))
        navigationItem.rightBarButtonItem = createPostsbutton
        createPostsbutton?.tintColor = .systemMint
        
        setupConstraint()
        
        // Refresh Control
        let refresh = UIRefreshControl()
        refresh.tintColor = .systemRed
        refresh.addTarget(self, action: #selector(refreshed), for: .valueChanged)
        postTable.refreshControl = refresh
    }
    
    func setupConstraint() {
        
        NSLayoutConstraint.activate([
            postTable.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            postTable.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            postTable.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            postTable.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
    }

    @objc func refreshed() {
        
    }
    
    @objc func createPost() {
        let createPostController = NewPostController()
        createPostController.delegate = self
        navigationController?.pushViewController(createPostController, animated: true)
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        posts.count
    }
    
    // create a new post
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier) as? PostCellController {
            let post = posts[indexPath.row]
            cell.configure(post: post)
            cell.accessoryType = .disclosureIndicator
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    // update a post
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let selectedPost = posts[indexPath.row]
        let updatePostController = UpdatePostController()
        updatePostController.delegate = self
        updatePostController.id = selectedPost.id?.uuidString
        updatePostController.titleField.text = selectedPost.title
        updatePostController.bodyField.text = selectedPost.body
        updatePostController.posterField.text = selectedPost.poster
        navigationController?.pushViewController(updatePostController, animated: true)
    }
}

extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    // Deletion (Swipe left!)
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            posts.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}

extension ViewController: CreateNewPostDelegate {
    func createNewPostDelegate(post: Model) {
        self.dismiss(animated: true) {
            self.posts.insert(post, at: 0)
            self.postTable.reloadData()
        }
    }
}

extension ViewController: UpdatePostDelegate {
    func updatePost(id: String?, title: String?, body: String?, poster: String?) {
        let currentPost = posts.filter({post in post.id?.uuidString == id})
        currentPost[0].title = title
        currentPost[0].body = body
        currentPost[0].poster = poster
        self.dismiss(animated: true) {
            self.postTable.reloadData()
        }
    }
}


