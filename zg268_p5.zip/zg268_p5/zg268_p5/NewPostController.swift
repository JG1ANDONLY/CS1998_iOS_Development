//
//  PostsController.swift
//  zg268_p5
//
//  Created by Zhongyi (James) Guo on 4/9/22.
//

import Foundation
import UIKit
import SwiftUI

protocol CreateNewPostDelegate {
    func createNewPostDelegate(post: Model)
}

class NewPostController: UIViewController {
    
    var delegate: CreateNewPostDelegate?
    var titleLabel = UILabel()
    var bodyLabel = UILabel()
    var posterLabel = UILabel()
    
    var titleField = UITextField()
    var bodyField = UITextField()
    var posterField = UITextField()
    
    var createPost = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        self.navigationController?.navigationBar.tintColor = .systemMint
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(handleCancel))
        
        titleLabel.text = "Title:"
        titleLabel.font = titleLabel.font.withSize(20)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)
        
        titleField.borderStyle = .roundedRect
        titleField.becomeFirstResponder()
        titleField.layer.cornerRadius = 5
        titleField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleField)
        
        bodyLabel.text = "Content:"
        bodyLabel.font = bodyLabel.font.withSize(20)
        bodyLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bodyLabel)
        
        
        bodyField.borderStyle = .roundedRect
        bodyField.layer.cornerRadius = 5
        bodyField.textAlignment = .left
        bodyField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.top
        bodyField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bodyField)
        
        posterLabel.text = "Poster:"
        posterLabel.font = posterLabel.font.withSize(20)
        posterLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(posterLabel)
        
        posterField.borderStyle = .roundedRect
        posterField.layer.cornerRadius = 5
        posterField.textAlignment = .left
        posterField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(posterField)
        
        createPost.setTitle("Create a Post", for: .normal)
        createPost.titleLabel?.font = createPost.titleLabel?.font.withSize(20)
        createPost.titleLabel?.textAlignment = .center
        createPost.backgroundColor = .systemMint
        createPost.layer.cornerRadius = 15
        createPost.tintColor = .systemBackground
        createPost.addTarget(self, action: #selector(createNewPost), for: .touchUpInside)
        createPost.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(createPost)

        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            titleField.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            titleField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            titleField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
        
        NSLayoutConstraint.activate([
            bodyLabel.topAnchor.constraint(equalTo: titleField.bottomAnchor, constant: 10),
            bodyLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            bodyField.topAnchor.constraint(equalTo: bodyLabel.bottomAnchor, constant: 10),
            bodyField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            bodyField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            bodyField.heightAnchor.constraint(equalToConstant: 200)
        ])
        
        NSLayoutConstraint.activate([
            posterLabel.topAnchor.constraint(equalTo: bodyField.bottomAnchor, constant: 10),
            posterLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10)
        ])
        
        NSLayoutConstraint.activate([
            posterField.topAnchor.constraint(equalTo: posterLabel.bottomAnchor, constant: 10),
            posterField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            posterField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10)
        ])
        
        NSLayoutConstraint.activate([
            createPost.topAnchor.constraint(equalTo: posterField.bottomAnchor, constant: 20),
            createPost.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            createPost.widthAnchor.constraint(equalToConstant: 200),
            createPost.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    @objc func createNewPost() {
        UIView.animate(withDuration: 0.1, animations: {self.createPost.transform = CGAffineTransform(scaleX: 0.85, y: 0.85)}, completion: { _ in UIView.animate(withDuration: 0.1) {self.createPost.transform = CGAffineTransform.identity}})
        if titleField.text! == "" {
            let alert = UIAlertController(title: "Invalid Title", message: "Please enter your title.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else if bodyField.text! == "" {
            let alert = UIAlertController(title: "Invalid Content", message: "Please enter your content.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else if posterField.text! == "" {
            let alert = UIAlertController(title: "Invalid Poster", message: "Please enter your poster name.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in print("OK button tapped")})
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        } else {
            delegate?.createNewPostDelegate(post: Model(title: titleField.text!, body: bodyField.text!, poster: posterField.text!))
            let alert = UIAlertController(title: nil, message: "New Post Created!", preferredStyle: .alert)
            present(alert, animated: true, completion: nil)
            dismiss(animated: true, completion: nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    

    @objc func handleCancel() {
        self.navigationController?.popViewController(animated: true)
    }
    
}
