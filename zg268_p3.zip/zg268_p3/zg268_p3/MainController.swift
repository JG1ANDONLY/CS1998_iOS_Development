//
//  ViewController.swift
//  zg268_p3
//
//  Created by 过仲懿 on 3/11/22.
//

import UIKit

class MainController: UIViewController {
    
    var photo = UIImageView()
    var name = UILabel()
    var website = UIButton()
    var path: String = "https://www.instagram.com/jamesguo.best/"
    var year = UILabel()
    var year_value = UILabel()
    var about = UILabel()
    var about_content = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .done, target: self, action: #selector(editProfileController))
        title = "My Profile"
        
        // photo
        photo.image = UIImage(named: "photo_1")
        photo.contentMode = .scaleToFill
        photo.clipsToBounds = true
        photo.layer.borderWidth = 1
        photo.layer.borderColor = UIColor.gray.cgColor
        photo.layer.cornerRadius = 91
        photo.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(photo)
        
        // name
        name.text = "James Guo"
        name.textColor = .black
        name.font = .systemFont(ofSize: 25, weight: .bold)
        name.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(name)
        
        // website
        website.setTitle(path, for: .normal)
        website.setTitleColor(.gray, for: .normal)
        website.titleLabel?.font = .systemFont(ofSize: 10)
        website.backgroundColor = .systemBackground
        website.addTarget(self, action: #selector(linkclicked), for: .touchUpInside)
        website.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(website)
        
        // year
        year.text = " Year: "
        year.textColor = .black
        year.font = .systemFont(ofSize: 20, weight: .bold)
        year.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(year)
        
        // year_value
        year_value.text = "Junior"
        year_value.textColor = .black
        year_value.font = .systemFont(ofSize: 20, weight: .bold)
        year_value.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(year_value)
        
        // about
        about.text = " About "
        about.textColor = .black
        about.font = .systemFont(ofSize: 20, weight: .bold)
        about.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(about)
        
        // about_content
        about_content.text = "Hi, my name is James Guo. I am a junior double majoring in Computational Biology and Biometry and Statistics at Cornell CALS. Please follow my instagram (link above), and let's become friends! "
        about_content.font = .systemFont(ofSize: 15)
        about_content.textColor = .lightGray
        about_content.backgroundColor = .systemGray6
        about_content.isEditable = false
        about_content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(about_content)
        
        // Set up constraints
        setupConstraints()
    }
        

    func setupConstraints() {
        NSLayoutConstraint.activate([
            photo.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            photo.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            photo.widthAnchor.constraint(equalToConstant: 180),
            photo.heightAnchor.constraint(equalToConstant: 180)
        ])
        NSLayoutConstraint.activate([
            name.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10),
            name.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor)
        ])
        NSLayoutConstraint.activate([
            website.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 10),
            website.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor)
        ])
        NSLayoutConstraint.activate([
            year.topAnchor.constraint(equalTo: website.bottomAnchor, constant: 10),
            year.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            year_value.topAnchor.constraint(equalTo: website.bottomAnchor, constant: 10),
            year_value.leftAnchor.constraint(equalTo: year.rightAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            about.topAnchor.constraint(equalTo: year.bottomAnchor, constant: 10),
            about.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            about_content.topAnchor.constraint(equalTo: about.bottomAnchor, constant: 10),
            about_content.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            about_content.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            about_content.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
    }
    
    @objc func editProfileController() {
        let edit = EditController()
        edit.parentController = self
        edit.original_photo = self.photo.image
        if year_value.text == "Freshman" {
            edit.slider_value_controll = 0
        } else if year_value.text == "Sophomore" {
            edit.slider_value_controll = 33.33
        } else if year_value.text == "Junior" {
            edit.slider_value_controll = 66.66
        } else {
            edit.slider_value_controll = 99.99
        }
        navigationController?.pushViewController(edit, animated: true)
    }
    
    @objc func linkclicked() {
        openUrl(urlStr: website.titleLabel?.text)
    }
    func openUrl(urlStr: String!) {
        if let url = URL(string:urlStr), !url.absoluteString.isEmpty {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    


}

