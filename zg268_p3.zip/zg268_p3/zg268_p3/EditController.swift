//
//  EditController.swift
//  zg268_p3
//
//  Created by 过仲懿 on 3/13/22.
//

import UIKit

class EditController: UIViewController {
    
    var parentController: MainController?
    var photo = UILabel()
    var photo_change = UIButton()
    var name = UILabel()
    var name_input = UITextField()
    var website = UILabel()
    var website_input = UITextField()
    var year = UILabel()
    let step: Float = 33.33
    var year_slider = UISlider()
    var about = UILabel()
    var about_content = UITextField()
    var freshman = UILabel()
    var senior = UILabel()
    var original_photo : UIImage?
    var slider_value_controll : Float?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        self.navigationItem.backButtonTitle = "Back"
        title = "Edit My Profile"
        
//        self.navigationItem.backBarButtonItem?.title = "Back"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(update))
        
        // photo
        photo.text = "Profile Photo"
        photo.textColor = .systemBlue
        photo.font = .systemFont(ofSize: 20, weight: .light)
        photo.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(photo)
        
        // photo_change
        photo_change.setImage(UIImage(named: "camera"), for: .normal)
        photo_change.contentMode = .scaleToFill
        photo_change.layer.borderWidth = 1
        photo_change.layer.borderColor = UIColor.lightGray.cgColor
        photo_change.layer.cornerRadius = 50
        photo_change.layer.masksToBounds = true
        photo_change.addTarget(self, action: #selector(photoEditController), for: .touchUpInside)
        photo_change.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(photo_change)
        
        // name
        name.text = "Name"
        name.textColor = .systemBlue
        name.font = .systemFont(ofSize: 20, weight: .light)
        name.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(name)
        
        // name_input
        name_input.placeholder = " Your Name"
        name_input.textColor = .black
        name_input.font = .systemFont(ofSize: 20, weight: .light)
        name_input.backgroundColor = .systemBackground
        name_input.layer.borderWidth = 1
        name_input.layer.borderColor = UIColor.lightGray.cgColor
        name_input.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(name_input)
        
        // website
        website.text = "Website"
        website.textColor = .systemBlue
        website.font = .systemFont(ofSize: 20, weight: .light)
        website.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(website)
        
        // website_input
        website_input.placeholder = " Your Website"
        website_input.textColor = .black
        website_input.font = .systemFont(ofSize: 20, weight: .light)
        website_input.backgroundColor = .systemBackground
        website_input.layer.borderWidth = 1
        website_input.layer.borderColor = UIColor.lightGray.cgColor
        website_input.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(website_input)
        
        // year
        year.text = "Year"
        year.textColor = .systemBlue
        year.font = .systemFont(ofSize: 20, weight: .light)
        year.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(year)
        
        // year_slider
        year_slider.tintColor = UIColor.magenta
        year_slider.minimumValue = 0
        year_slider.maximumValue = 100
        if parentController?.year_value.text! == "Freshman" {
            year_slider.value = 0
        } else if parentController?.year_value.text! == "Sophomore" {
            year_slider.value = 33.33
        } else if parentController?.year_value.text! == "Junior" {
            year_slider.value = 66.66
        } else {
            year_slider.value = 99.99
        }
        year_slider.addTarget(self, action: #selector(self.sliderValueDidChange(_:)), for: .valueChanged)
        year_slider.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(year_slider)
        
        
        // freshman
        freshman.text = "1st"
        freshman.textColor = .lightGray
        freshman.font = .systemFont(ofSize: 18)
        freshman.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(freshman)
        
        // senior
        senior.text = "4th"
        senior.textColor = .lightGray
        senior.font = .systemFont(ofSize: 18)
        senior.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(senior)
        
        // about
        about.text = "About"
        about.textColor = .systemBlue
        about.font = .systemFont(ofSize: 20, weight: .light)
        about.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(about)
        
        // about_content
        about_content.placeholder = " Your About"
        about_content.textColor = .black
        about_content.font = .systemFont(ofSize: 20, weight: .light)
        about_content.backgroundColor = .systemBackground
        about_content.layer.borderWidth = 1
        about_content.layer.borderColor = UIColor.lightGray.cgColor
        about_content.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(about_content)
        
        // Set up constraints
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            photo.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 20),
            photo.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            photo_change.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 20),
            photo_change.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            photo_change.heightAnchor.constraint(equalToConstant: 100),
            photo_change.widthAnchor.constraint(equalToConstant: 100)
        ])
        NSLayoutConstraint.activate([
            name.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 20),
            name.topAnchor.constraint(equalTo: photo_change.bottomAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            name_input.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 10),
            name_input.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            name_input.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            name_input.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            name_input.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            website.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 20),
            website.topAnchor.constraint(equalTo: name_input.bottomAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            website_input.topAnchor.constraint(equalTo: website.bottomAnchor, constant: 10),
            website_input.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            website_input.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            website_input.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            website_input.heightAnchor.constraint(equalToConstant: 40)
        ])
        NSLayoutConstraint.activate([
            year.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            year.topAnchor.constraint(equalTo: website_input.bottomAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            year_slider.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            year_slider.topAnchor.constraint(equalTo: freshman.bottomAnchor),
            year_slider.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20)
        ])
        NSLayoutConstraint.activate([
            freshman.leadingAnchor.constraint(equalTo: year_slider.leadingAnchor),
            freshman.topAnchor.constraint(equalTo: year.bottomAnchor)
        ])
        NSLayoutConstraint.activate([
            senior.trailingAnchor.constraint(equalTo: year_slider.trailingAnchor),
            senior.topAnchor.constraint(equalTo: year.bottomAnchor)
        ])
        NSLayoutConstraint.activate([
            year_slider.topAnchor.constraint(equalTo: freshman.bottomAnchor)
        ])
        NSLayoutConstraint.activate([
            about.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 20),
            about.topAnchor.constraint(equalTo: year_slider.bottomAnchor, constant: 20)
        ])
        NSLayoutConstraint.activate([
            about_content.topAnchor.constraint(equalTo: about.bottomAnchor, constant: 10),
            about_content.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            about_content.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20),
            about_content.heightAnchor.constraint(equalToConstant: 200)
        ])

    }
    
    @objc func update() {
        if photo_change.currentImage! != UIImage(named: "camera") {
            parentController?.photo.image = photo_change.currentImage!
        }
        if name_input.text != "" {
            parentController?.name.text = name_input.text
        }
        
        if website_input.text != "" {
            if verifyUrl(urlString: website_input.text!) {
                parentController?.website.setTitle(website_input.text, for: .normal)
            } else {
                guard let updated_website = website_input.text, verifyUrl(urlString: updated_website) else {WebsiteshowAlert(); return};
            }
        }
        
        if year_slider.value == 0 {
            parentController?.year_value.text = "Freshman"
        } else if year_slider.value ==  33.33 {
            parentController?.year_value.text = "Sophomore"
        } else if year_slider.value ==  66.66 {
            parentController?.year_value.text = "Junior"
        } else {
            parentController?.year_value.text = "Senior"
        }
        
        if about_content.text != "" {
            parentController?.about_content.text = about_content.text
        }
        
        let action: Bool = (photo_change.currentImage! != UIImage(named: "camera")) || (name_input.text != "") || (website_input.text != "") || (year_slider.value != slider_value_controll!) || (about_content.text != "")
        if action {
            let saved = UIAlertController(title: "Saved", message: "Edit saved", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("OK button tapped")
            })
            saved.addAction(ok)
            navigationController?.present(saved, animated: true, completion: nil)
        }
    }

    @objc func photoEditController() {
        let photoedit = PhotoEditController()
        photoedit.parentedit = self
        photoedit.originalphoto = self.original_photo
        navigationController?.present(photoedit, animated: true, completion: nil)
    }
    
    @objc func sliderValueDidChange(_ sender:UISlider!) {
        let roundedStepValue = round(sender.value / step) * step
        sender.value = roundedStepValue
    }
    
    @objc func WebsiteshowAlert() {
        let alert = UIAlertController(title: "Error in Editing Website", message: "Invalid Input for Website", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .cancel, handler: { (action) -> Void in
            print("OK button tapped")
        })
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    func verifyUrl (urlString: String?) -> Bool {
        if let urlString = urlString {
            if let url = NSURL(string: urlString) {
                return UIApplication.shared.canOpenURL(url as URL)
            }
        }
        return false
    }
}


