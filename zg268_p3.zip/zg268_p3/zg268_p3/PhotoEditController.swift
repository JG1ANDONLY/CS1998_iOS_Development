//
//  PhotoEditController.swift
//  zg268_p3
//
//  Created by 过仲懿 on 3/14/22.
//

import UIKit


class PhotoEditController: UIViewController {

    var parentedit: EditController?
    var originalphoto: UIImage?
    var yourphoto = UILabel()
    var photo = UIImageView()
    var isHighLighted = false
    var newphoto1 = UIButton()
    var newphoto2 = UIButton()
    var newphoto3 = UIButton()
    var newphoto4 = UIButton()
    var newphoto5 = UIButton()
    var newphoto6 = UIButton()
    var save = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        
        // yourphoto
        yourphoto.text = "Change Your Photo"
        yourphoto.textColor = .black
        yourphoto.font = .systemFont(ofSize: 25, weight: .bold)
        yourphoto.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(yourphoto)
        
        // photo
        photo.image = originalphoto
        photo.contentMode = .scaleToFill
        photo.clipsToBounds = true
        photo.layer.borderWidth = 1
        photo.layer.borderColor = UIColor.gray.cgColor
        photo.layer.cornerRadius = 50
        photo.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(photo)

        // newphotos
        newphoto1.setImage(UIImage(named: "photo_1"), for: .normal)
        newphoto1.contentMode = .scaleToFill
        newphoto1.layer.borderWidth = 1
        newphoto1.layer.borderColor = UIColor.lightGray.cgColor
        newphoto1.layer.cornerRadius = 65
        newphoto1.layer.masksToBounds = true
        newphoto1.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto1.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto1)
        
        newphoto2.setImage(UIImage(named: "photo_3"), for: .normal)
        newphoto2.contentMode = .scaleToFill
        newphoto2.layer.borderWidth = 1
        newphoto2.layer.borderColor = UIColor.lightGray.cgColor
        newphoto2.layer.cornerRadius = 65
        newphoto2.layer.masksToBounds = true
        newphoto2.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto2.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto2)
        
        newphoto3.setImage(UIImage(named: "photo_4"), for: .normal)
        newphoto3.contentMode = .scaleToFill
        newphoto3.layer.borderWidth = 1
        newphoto3.layer.borderColor = UIColor.lightGray.cgColor
        newphoto3.layer.cornerRadius = 65
        newphoto3.layer.masksToBounds = true
        newphoto3.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto3.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto3)
        
        newphoto4.setImage(UIImage(named: "photo_5"), for: .normal)
        newphoto4.contentMode = .scaleToFill
        newphoto4.layer.borderWidth = 1
        newphoto4.layer.borderColor = UIColor.lightGray.cgColor
        newphoto4.layer.cornerRadius = 65
        newphoto4.layer.masksToBounds = true
        newphoto4.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto4.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto4)
        
        newphoto5.setImage(UIImage(named: "photo_6"), for: .normal)
        newphoto5.contentMode = .scaleToFill
        newphoto5.layer.borderWidth = 1
        newphoto5.layer.borderColor = UIColor.lightGray.cgColor
        newphoto5.layer.cornerRadius = 65
        newphoto5.layer.masksToBounds = true
        newphoto5.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto5.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto5)
        
        newphoto6.setImage(UIImage(named: "photo_7"), for: .normal)
        newphoto6.contentMode = .scaleToFill
        newphoto6.layer.borderWidth = 1
        newphoto6.layer.borderColor = UIColor.lightGray.cgColor
        newphoto6.layer.cornerRadius = 65
        newphoto6.layer.masksToBounds = true
        newphoto6.addTarget(self, action: #selector(buttonClicked), for: .touchUpInside)
        newphoto6.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(newphoto6)
        
        // save
        save.setTitle("Save", for: .normal)
        save.titleLabel?.font = .systemFont(ofSize: 25)
        save.setTitleColor(.systemBackground, for: .normal)
        save.backgroundColor = .systemBlue
        save.layer.cornerRadius = 5
        save.addTarget(self, action: #selector(update), for: .touchUpInside)
        save.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(save)
        
        // Set up constraints
        setupConstraints()
    }
    
    @objc func setupConstraints() {
        NSLayoutConstraint.activate([
            yourphoto.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            yourphoto.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor)
        ])
        NSLayoutConstraint.activate([
            photo.topAnchor.constraint(equalTo: yourphoto.bottomAnchor, constant: 20),
            photo.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            photo.widthAnchor.constraint(equalToConstant: 100),
            photo.heightAnchor.constraint(equalToConstant: 100)
        ])
        NSLayoutConstraint.activate([
            newphoto1.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 20),
            newphoto1.widthAnchor.constraint(equalToConstant: 130),
            newphoto1.heightAnchor.constraint(equalToConstant: 130),
            newphoto1.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 45),
            newphoto2.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 20),
            newphoto2.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -45),
            newphoto2.widthAnchor.constraint(equalToConstant: 130),
            newphoto2.heightAnchor.constraint(equalToConstant: 130),
            newphoto3.topAnchor.constraint(equalTo: newphoto1.bottomAnchor, constant: 20),
            newphoto3.widthAnchor.constraint(equalToConstant: 130),
            newphoto3.heightAnchor.constraint(equalToConstant: 130),
            newphoto3.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 45),
            newphoto4.topAnchor.constraint(equalTo: newphoto2.bottomAnchor, constant: 20),
            newphoto4.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -45),
            newphoto4.widthAnchor.constraint(equalToConstant: 130),
            newphoto4.heightAnchor.constraint(equalToConstant: 130),
            newphoto5.topAnchor.constraint(equalTo: newphoto3.bottomAnchor, constant: 20),
            newphoto5.widthAnchor.constraint(equalToConstant: 130),
            newphoto5.heightAnchor.constraint(equalToConstant: 130),
            newphoto5.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 45),
            newphoto6.topAnchor.constraint(equalTo: newphoto4.bottomAnchor, constant: 20),
            newphoto6.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -45),
            newphoto6.widthAnchor.constraint(equalToConstant: 130),
            newphoto6.heightAnchor.constraint(equalToConstant: 130)
        ])
        NSLayoutConstraint.activate([
            save.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            save.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            save.widthAnchor.constraint(equalToConstant: 100)
        ])
    }
    
    @objc func buttonClicked(sender:UIButton) {
        sender.isSelected = true
        isHighLighted = true
        photo.image = sender.currentImage!
        sender.isSelected = false
    }
    
    @objc func update() {
        parentedit?.photo_change.setImage(photo.image, for: .normal)
        dismiss(animated: true, completion: nil)
    }
}
