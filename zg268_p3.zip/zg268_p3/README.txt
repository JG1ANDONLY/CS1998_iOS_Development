This is a README text file for extra credits for project 3.

1. There are 5 fields: profile photo, name, website, year, and about. You can update either one, or combinations, or all of them.

2. I implemented a hyperlink for the website, and when you click on the link, it should direct you to the website through Safari. You should enter a valid Url!

I hope you enjoy my app!