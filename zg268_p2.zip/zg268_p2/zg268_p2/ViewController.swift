//
//  ViewController.swift
//  zg268_p2
//
//  Created by 过仲懿 on 3/6/22.
//

import UIKit

extension String {
    var isInt: Bool {
        return Int(self) != nil
    }
}

class ViewController: UIViewController {
    
    var label = UILabel()
    var buttonswitch = UISwitch()
    var image = UIImageView()
    var buttonAdd = UIButton()
    var textfield_event = UITextField()
    var textfield_time = UITextField()
    var textfield_delete = UITextField()
    var buttondelete = UIButton()
    var textview_min = UITextView()
    var textview = UITextView()
//    var seg = UISegmentedControl(items: ["hours", "minutes"])
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        
        // Label
        label.text = "To-Do List"
        label.textColor = UIColor(red: 150/255, green: 84/255, blue: 84/255, alpha: 1.0)
        label.font = .systemFont(ofSize: 30, weight: .heavy)
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        
        // Switch
        buttonswitch.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(buttonswitch)
        
        // Image
        image.image = UIImage(named: "todo")
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        image.layer.cornerRadius = 5
        image.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(image)
        
        // Button
        buttonAdd.setTitle(" Add ", for: .normal)
        buttonAdd.setTitleColor(.systemBackground, for: .normal)
        buttonAdd.layer.borderWidth = 1
        buttonAdd.layer.borderColor = UIColor.systemBlue.cgColor
        buttonAdd.backgroundColor = .blue
        buttonAdd.layer.cornerRadius = 10
        buttonAdd.translatesAutoresizingMaskIntoConstraints = false
        buttonAdd.addTarget(self, action: #selector(buttonAddTapped), for: .touchUpInside)
        view.addSubview(buttonAdd)
        
        // TextField - Event
        textfield_event.placeholder = "Event"
        textfield_event.font = .systemFont(ofSize: 15, weight: .heavy)
        textfield_event.textColor = .black
        textfield_event.borderStyle = .roundedRect
        textfield_event.layer.cornerRadius = 10
        textfield_event.becomeFirstResponder()
        textfield_event.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textfield_event)
        
        // TextField - Time
        textfield_time.placeholder = "Est time"
        textfield_time.font = .systemFont(ofSize: 15, weight: .heavy)
        textfield_time.textColor = .black
        textfield_time.borderStyle = .roundedRect
        textfield_time.layer.cornerRadius = 10
        textfield_time.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textfield_time)
        
        // TextView - Minute
        textview_min.text = " min "
        textview_min.textColor = .black
        textview_min.font = .systemFont(ofSize: 15, weight: .bold)
        textview_min.backgroundColor = .systemBackground
        textview_min.isScrollEnabled = true
        textview_min.isEditable = false
        textview_min.isSelectable = true
        textview_min.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textview_min)
        
        // TextField - Delete
        textfield_delete.placeholder = "Delete ..."
        textfield_delete.font = .systemFont(ofSize: 15, weight: .heavy)
        textfield_delete.textColor = .black
        textfield_delete.borderStyle = .roundedRect
        textfield_delete.layer.cornerRadius = 10
        textfield_delete.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textfield_delete)
        
        // Button Delete
        buttondelete.setTitle(" Delete ", for: .normal)
        buttondelete.setTitleColor(.systemBackground, for: .normal)
        buttondelete.layer.borderWidth = 1
        buttondelete.layer.borderColor = UIColor.systemRed.cgColor
        buttondelete.backgroundColor = .red
        buttondelete.layer.cornerRadius = 10
        buttondelete.translatesAutoresizingMaskIntoConstraints = false
        buttondelete.addTarget(self, action: #selector(buttonDeleteTapped), for: .touchUpInside)
        view.addSubview(buttondelete)
        
        
        // TextView
        textview.text = "I need to:"
        textview.textColor = .black
        textview.font = .systemFont(ofSize: 20, weight: .light)
        textview.backgroundColor = .systemBackground
        textview.layer.borderColor = UIColor.lightGray.cgColor
        textview.layer.borderWidth = 1
        textview.layer.cornerRadius = 5
        textview.isScrollEnabled = true
        textview.isEditable = false
        textview.isSelectable = true
        textview.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(textview)
        
        // Constraints
        setConstraints()
    }

    func setConstraints(){
        // For Label
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            label.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        // For Switch
        NSLayoutConstraint.activate([
            buttonswitch.centerYAnchor.constraint(equalTo: label.centerYAnchor),
            buttonswitch.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -20),
        ])

        // For Image
        NSLayoutConstraint.activate([
            image.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 20),
            image.centerXAnchor.constraint(equalTo: label.centerXAnchor),
        ])
        
        // For TextField - Event
        NSLayoutConstraint.activate([
            textfield_event.topAnchor.constraint(equalTo: image.bottomAnchor, constant: 20),
            textfield_event.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textfield_event.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
         ])
        
        // For Button
        NSLayoutConstraint.activate([
            buttonAdd.topAnchor.constraint(equalTo: textfield_event.bottomAnchor, constant: 10),
            buttonAdd.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            buttonAdd.widthAnchor.constraint(equalToConstant: 80)
         ])
        
        // For TextField - Time
        NSLayoutConstraint.activate([
            textfield_time.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textfield_time.centerYAnchor.constraint(equalTo: buttonAdd.centerYAnchor),
            textfield_time.trailingAnchor.constraint(equalTo: textview_min.leadingAnchor, constant: -20)
         ])
        
        // For TextView - Minute
        NSLayoutConstraint.activate([
            textview_min.widthAnchor.constraint(equalToConstant: 50),
            textview_min.topAnchor.constraint(equalTo: buttonAdd.topAnchor),
            textview_min.bottomAnchor.constraint(equalTo: buttonAdd.bottomAnchor),
            textview_min.leadingAnchor.constraint(equalTo: textfield_time.trailingAnchor, constant: 20),
            textview_min.trailingAnchor.constraint(equalTo: buttonAdd.leadingAnchor, constant: -20)
         ])
        
        // For Button Delete
        NSLayoutConstraint.activate([
            buttondelete.topAnchor.constraint(equalTo: buttonAdd.bottomAnchor, constant: 10),
            buttondelete.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            buttondelete.widthAnchor.constraint(equalToConstant: 80)
         ])
        
        // For TextField - Delete
        NSLayoutConstraint.activate([
            textfield_delete.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),
            textfield_delete.topAnchor.constraint(equalTo: buttonAdd.bottomAnchor, constant: 10),
            textfield_delete.trailingAnchor.constraint(equalTo: buttondelete.leadingAnchor, constant: -20)
         ])
        
        // For TextView
        NSLayoutConstraint.activate([
            textview.topAnchor.constraint(equalTo: buttondelete.bottomAnchor, constant: 20),
            textview.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -15),
            textview.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            textview.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
         ])
    }
    
    
    @objc func buttonAddTapped() {
        if buttonswitch.isOn {
            if textfield_event.text! == "" {
                let emptyeventwarning = UIAlertController(title: "Empty Event", message: "Please enter a valid event!", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
                })
                emptyeventwarning.addAction(ok)
                self.present(emptyeventwarning, animated: true, completion: nil)
            }
            else if textfield_time.text! == "" {
                let emptytimewarning = UIAlertController(title: "Empty Time", message: "Please enter a valid estimated time!", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
                })
                emptytimewarning.addAction(ok)
                self.present(emptytimewarning, animated: true, completion: nil)
            }
            else if !String(textfield_time.text!).isInt {
                let notintwarning = UIAlertController(title: "Not an integer", message: "Please enter an integer for estimated time!", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
                })
                notintwarning.addAction(ok)
                self.present(notintwarning, animated: true, completion: nil)
            }
            else {
                let textview_text = textview.text!
                let event_text = textfield_event.text!
                let time_text = textfield_time.text!
                textview.text = textview_text.appending("\n" + event_text + " (\(time_text) min)")
            }
        }
    }
    
    @objc func buttonDeleteTapped() {
        if buttonswitch.isOn {
            let textview_text = textview.text!
            let delete_text = textfield_delete.text!
            let len_delete_text = delete_text.count
            if textview_text.contains(delete_text){
                if let range = textview_text.range(of: delete_text) {
                    let startPos = textview_text.distance(from: textview_text.startIndex, to: range.lowerBound)
                    let ineedto = textview_text.prefix(11)
                    let substring1 = textview_text.dropFirst(11).prefix(startPos - 11)
                    let substring2 = textview_text.dropFirst(ineedto.count + substring1.count + len_delete_text + 9)
                    let new_textview_text = "\(ineedto)\(substring1)\(substring2)"
                    textview.text = new_textview_text
                }
            }
            else {
                let notinwarning = UIAlertController(title: "No matching event", message: "Please enter an valid event!", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                print("Ok button tapped")
                    })
                notinwarning.addAction(ok)
                self.present(notinwarning, animated: true, completion: nil)
            }
        }
    }
}
