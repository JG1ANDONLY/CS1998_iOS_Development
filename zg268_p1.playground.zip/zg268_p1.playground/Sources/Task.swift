import Foundation

public enum Role: CaseIterable, Hashable {
    case iOS
    case Backend
    case Design
    case Android
    case Marketing
}


public struct Member: Equatable {
    public var name: String
    public var netid: String
    public var role: Role
    
    public init(name: String, netid: String, role: Role) { // I only needed to add this because playgrounds suck
        self.name = name
        self.netid = netid
        self.role = role
    }
}

public protocol Task {
/**
* Note our use of camelCase and how the below properties are set to `get`-only because it doesn't make sense to change them
* In fact, it might break your program if they change later (hence why it is forced)
*/
    var name: String { get }
    var completed: Bool { get set }
    var requiredRoles: [Role] { get }
    var assignedMembers: [Member]? { get set } // You get to see members later
    init(name: String, completed: Bool, requiredRoles: [Role], assignedMembers: [Member]?)
}

public class ClassTask: Task {
    
    public var name: String
    public var completed: Bool
    public var requiredRoles: [Role]
    public var assignedMembers: [Member]?
    
    public required init(name: String, completed: Bool = false, requiredRoles: [Role], assignedMembers: [Member]? = nil) {
        /**
         We added a default value to make initializing easier–defaults are always appreciated, so try to incorporate them in your code if / when they can be helpful :)
         The `required` keyword is only necessary because the `init` is in the `Task` protocol.
        */
        self.name = name
        self.completed = completed
        self.requiredRoles = requiredRoles
        self.assignedMembers = assignedMembers
    }
    
}

public struct StructTask: Task {
    
    public var name: String
    public var completed: Bool
    public var requiredRoles: [Role]
    public var assignedMembers: [Member]?
//    Another side note about `required`, its not necessary in structs, as for why not ¯\_(ツ)_/¯
    public init(name: String, completed: Bool = false, requiredRoles: [Role], assignedMembers: [Member]? = nil) {
        self.name = name
        self.completed = completed
        self.requiredRoles = requiredRoles
        self.assignedMembers = assignedMembers
    }
    
}

public protocol Group {
    
    var members: [Member] { get }
    
    var completedTasks: [Task] { get set }
    var incompleteTasks: [Task] { get set }
    
    init(members: [Member], tasks: [Task]) // You cannot assume these tasks are incomplete.
}
