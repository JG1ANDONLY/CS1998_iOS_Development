import Foundation

public typealias Test = () throws -> Void
public typealias TestCase = (String, Test)

public func >>= (_ lhs: String, _ rhs: @escaping Test) -> TestCase {
    return (lhs, rhs)
}
public class TestManager {
    
    static let Noah = Member(name: "Noah Pikielny", netid: "np299", role: .Backend)
    public static let ideate = StructTask(name: "Ideate", completed: true, requiredRoles: Role.allCases)
    public static let formGroup = StructTask(name: "Form Group", requiredRoles: Role.allCases)
    public static let assignedTasks = StructTask(name: "Assign Members", requiredRoles: [], assignedMembers: [Noah])
    public static let emptyTasks = StructTask(name: "Unassigned Members", requiredRoles: [], assignedMembers: [])
    static let anotherCompletedTask = StructTask(name: "I've lost my creativity at this point", completed: true, requiredRoles: [])
    
    public enum TestError: Error {
        case incorrectFields([(String, Any, Any)])
        case incorrectLength(expectedLength: Int, recievedLength: Int)
        case missingElement(element: String)
        case incorrectValue(Any)
    }
    
    public static func correctField(task: Task, correctTask: Task) throws -> Void {
        let fields: [(String, Bool, Any, Any)] = [
            ("name", task.name == correctTask.name, task.name, correctTask.name),
            ("completed", task.completed == correctTask.completed, task.completed, correctTask.completed),
            ("requiredRoles", Set(task.requiredRoles) == Set(correctTask.requiredRoles), task.requiredRoles, correctTask.requiredRoles),
            ("assignedMembers", task.assignedMembers ?? [] == correctTask.assignedMembers ?? [], task.assignedMembers ?? [], correctTask.assignedMembers ?? [])
        ]
        let incorrectFields = fields.filter({ !$0.1 }).map({ ($0.0, $0.2, $0.3) })
        if incorrectFields.count > 0 {
            throw TestError.incorrectFields(incorrectFields)
        }
    }
    
    
    public static func runTests(tests: [TestCase], name: String) {
        var failedTests = [(String, String)]()
        for test in tests {
            do {
                try test.1()
            } catch TestError.incorrectFields(let fields) { failedTests.append((test.0, fields.reduce("", { p, mismatch in p +
                "Field \(mismatch.0) expected \(mismatch.2), but got \(mismatch.1)"
            }) ))
            } catch TestError.incorrectLength(let expectedLength, let recievedLength) {
                failedTests.append((test.0, "Expected array of size \(expectedLength), but got \(recievedLength)"))
                
            } catch TestError.missingElement(let element) {
                failedTests.append((test.0, "missing elememt \(element)"))
            } catch {
                failedTests.append((test.0, "Uncharacterized error: \(error)"))
            }
        }
        if failedTests.count > 0 {
            print(name + " failed \(failedTests.count) tests: ")
            for failedTest in failedTests {
                print("Failed \(failedTest.0) because: \(failedTest.1)")
            }
        } else {
            print("All \(name) Tests Passed")
        }
    }
    
    public static func part1Tests(mutableTask: Task, immutableTask: Task) -> [TestCase] {
        return [
            "ImmutableTask" >>= { try TestManager.correctField(task: mutableTask, correctTask: TestManager.ideate) },
            "MutableTask" >>= { try TestManager.correctField(task: immutableTask, correctTask: TestManager.formGroup) }
        ]
    }
    
    static func checkArray(array: [Task], expectedLength: Int, expectedTasks: [Task]) throws {
        if array.count != expectedLength {
            throw TestError.incorrectLength(expectedLength: expectedTasks.count, recievedLength: array.count)
        }
        for task in expectedTasks {
            guard let resultTask = expectedTasks.first(where: { $0.name == task.name }) else {
                throw TestError.missingElement(element: task.name)
            }
            try TestManager.correctField(task: resultTask, correctTask: task)
        }
    }
    
    public static func part2Tests(_ part2A: @escaping () -> [Task],
                                  _ part2B: @escaping ([Task], Task) -> [Task],
                                  _ part2C: @escaping ([Task]) -> [Task],
                                  _ part2D: @escaping ([Task], [Task]) -> [Task]) -> [TestCase] {
        let partAResult = part2A()
        let newTask = StructTask(name: "SomeTask", requiredRoles: [])
        let partBResult = part2B(partAResult, newTask)
        let secondNewTask = StructTask(name: "SomeOtherTask", requiredRoles: [])
        let partCResult = part2C(part2B(partBResult, secondNewTask))
        let part2DResult = part2D(partCResult, [secondNewTask, TestManager.ideate])
        return [
            "Part 2A" >>= {
                try TestManager.checkArray(array: partAResult, expectedLength: 2, expectedTasks: [TestManager.ideate, TestManager.formGroup])
            },
            "Part 2B" >>= {
                try TestManager.checkArray(array: partBResult, expectedLength: 3, expectedTasks: [TestManager.ideate, TestManager.formGroup, newTask])
            },
            "Part 2C" >>= {
                try TestManager.checkArray(array: partCResult, expectedLength: 2, expectedTasks: [TestManager.formGroup, newTask])
            },
            "Part 2D" >>= {
                try TestManager.checkArray(array: part2DResult, expectedLength: 2 + 2, expectedTasks: [TestManager.formGroup, newTask, secondNewTask, TestManager.ideate])
            }
        ]
    }
    
    public static func part3Tests(_ isCompleted: @escaping (Task) -> Bool, _ isIncomplete: @escaping (Task) -> Bool) -> [TestCase] {
        let completedTask = StructTask(name: "SomeTask", completed: true, requiredRoles: [])
        let incompleteTask = StructTask(name: "SomeTask", completed: false, requiredRoles: [])
        return [
            "isCompleted" >>= {
                if !isCompleted(completedTask) { throw TestError.incorrectValue(false) }
                if isCompleted(incompleteTask) { throw TestError.incorrectValue(true) }
            },
            "isIncomplete" >>= {
                if isIncomplete(completedTask) { throw TestError.incorrectValue(true) }
                if !isIncomplete(incompleteTask) { throw TestError.incorrectValue(false) }
            }
        ]
    }
    
    public static func part4Tests(_ remainingTasks: @escaping ([Task]) -> [Task]) -> [TestCase]{
        let result = remainingTasks([TestManager.ideate, TestManager.formGroup])
        return [
            "Remaining Tasks" >>= {
                try checkArray(array: result, expectedLength: 1, expectedTasks: [TestManager.ideate])
            }
        ]
    }
    
    public static func part5Tests(_ partA: @escaping (Task) -> Bool, _ partB: @escaping ([Task]) -> [Role: [Task]]) -> [TestCase] {
        return [
            "Part 5A" >>= {
                if !partA(assignedTasks) { throw TestError.incorrectValue("Returned false when should be true") }
                if partA(emptyTasks) { throw TestError.incorrectValue("Did not cover empty list") }
                if partA(TestManager.ideate) { throw TestError.incorrectValue("Returned True for nil") }
            },
            "Part 5B" >>= {
                let tasks = [
                    StructTask(name: "Task 1", requiredRoles: [.iOS]),
                    StructTask(name: "Task 2", requiredRoles: [.Backend, .Android]),
                    StructTask(name: "Task 3", requiredRoles: []),
                    StructTask(name: "Task 4", requiredRoles: [.iOS, .Backend, .Android, .Marketing])
                ]
                let result = partB(tasks)
                let data: [Role: [Task]] = [
                    .iOS: [tasks[0], tasks[3]],
                    .Backend: [tasks[1], tasks[3]],
                    .Android: [tasks[1], tasks[3]],
                    .Marketing: [tasks[3]]
                ]
                for role in Role.allCases {
                    if let expected = data[role], let result = result[role] {
                        try checkArray(array: result, expectedLength: expected.count, expectedTasks: expected)
                    } else if let _ = data[role] {
                        throw TestError.incorrectValue("Missing key-value pair \(role)")
                    } else if let _ = result[role] {
                        throw TestError.incorrectValue("Extra key-value pair \(role)")
                    }
                }
            }
        ]
    }
    
    public static func part6Tests(_ function: @escaping (Member) -> String) -> [TestCase] {
        let createMember: (Role) -> Member = { role in
            return Member(name: "\(role)", netid: "\(role)", role: role)
        }
        let generateError: (Role) -> TestError = { role in
            return TestError.incorrectValue("Incorrect message for \(role)")
        }
        
        return [
            "iOS" >>= { if function(createMember(.iOS)) != "Hello, \(Role.iOS)! Have a nice day :)" { throw generateError(.iOS) }},
            "Backend" >>= { if function(createMember(.Backend)) != "Hello, \(Role.Backend)! Get to work!" { throw generateError(.Backend) }},
            "Marketing" >>= { if function(createMember(.Marketing)) != "Hello, \(Role.Marketing)... Do whatever it is that you need to do." { throw generateError(.Marketing) }},
            "Design" >>= { if function(createMember(.Design)) != "Hello \(Role.Design)! Consider switching to iOS" { throw generateError(.Design) }},
            "Android" >>= { if function(createMember(.Android)) != "Hello \(Role.Android)! Consider switching to iOS" { throw generateError(.Android) }},
        ]
    }
    
    public static func checkGroup(group: Group, members: [Member], completedTasks: [Task], incompleteTasks: [Task]) throws {
        if group.members != members {
            throw TestError.incorrectFields([("Members", group.members, members)])
        }
        do {
            try checkArray(array: group.completedTasks, expectedLength: completedTasks.count, expectedTasks: completedTasks)
            try checkArray(array: group.incompleteTasks, expectedLength: incompleteTasks.count, expectedTasks: incompleteTasks)
        } catch {
            throw error
        }
    }

    public static func part8Tests(_ groupImplementation: Group.Type, extraCredit: Bool) -> [TestCase] {

        var emptyGroup = groupImplementation.init(
            members: [],
            tasks: []
        )

        let createGroup: () -> Group = {
            return groupImplementation.init(
                members: [TestManager.Noah],
                tasks: [TestManager.ideate, TestManager.formGroup]
            )
        }
        let staticGroup = createGroup()

        let basicTests: [TestCase] = [
            "Empty Inputs" >>= { try checkGroup(group: emptyGroup, members: [], completedTasks: [], incompleteTasks: []) },
            "Static Group" >>= { try checkGroup(group: staticGroup, members: [TestManager.Noah], completedTasks: [TestManager.formGroup], incompleteTasks: [TestManager.ideate]) }
        ]
        if !extraCredit {
            var dynamicGroup = createGroup()
            dynamicGroup.completedTasks = staticGroup.completedTasks + [anotherCompletedTask]
            dynamicGroup.incompleteTasks = staticGroup.incompleteTasks + [TestManager.emptyTasks]
            return basicTests + [
                "Edited Group" >>= { try checkGroup(group: dynamicGroup,
                                              members: [TestManager.Noah],
                                              completedTasks: staticGroup.completedTasks + [anotherCompletedTask],
                                              incompleteTasks: staticGroup.incompleteTasks + [TestManager.emptyTasks]) }
            ]
        } else {
            var dynamicGroup = createGroup()
            let ideateComplete = StructTask(name: "Ideate", completed: true, requiredRoles: Role.allCases)
            dynamicGroup.completedTasks.append(ideateComplete)
            return basicTests + [
                "Extra Credit Test" >>= { try checkGroup(
                    group: dynamicGroup,
                    members: [TestManager.Noah],
                    completedTasks: staticGroup.completedTasks + [ideateComplete],
                    incompleteTasks: [TestManager.formGroup]) }
            ]
        }
    }
    
}
