//: # Project 1
/** <James Guo zg268> */

/*: Please look on the [course website](https://app.gitbook.com/@cuappdev/s/intro-to-ios-development/) for directions on how to submit (ie. name your project 1 file netid_p1.playground and zip it as netid_p1.zip)

Project Goal: Become familiar with Swift syntax and basic Swift features.
PLEASE READ ALL PARTS CAREFULLY! THERE ARE A TOTAL OF 10 PARTS TO COMPLETE.

You'll notice that the structure of the project is slightly unwieldy–everything is in functions. This is to help make the test cases below. After every section, uncomment the corresponding test cases to check if what you did is right! Also, I will be interspersing some superfluous Swift knowledge just for educational and comfortability reasons. You only need to understand what was covered in class.

 In this assignment we will be designing the logic for an app that will manage tasks for hack challenge groups. We have moved all of the supporting code into two files, which you can see if you press `command 1` and hide with `command 0` :
 * Sources/Task
 * Sources/TestSuite

Please review the `Task` protocol in Sources/Task and come back by clicking on the topmost file (Project1) in the project navigator. You'll notice that I threw in `public` everywhere, **You will never need to do this!** I only did it because **playgrounds suck.** You don't need to look at TestSuite–although it may be a fun and educational exercise to do *after* completing the assignment.
 
Let's get to coding 🥳😋
*/

/*:
# Part 1 – The Basics
Mutability is important to manage when developing–we don't want certain things to change
## Part A:
Create two uncompleted tasks with all roles required,

 * A mutable task `{ name: "Ideate", completed: false, requiredRoles: All, assignedMembers: nil }`
 * An immutable task `{ name: "Form Group", completed: false, requiredRoles: All, assignedMembers: nil }`

These can be either `ClassTask`s or `StructTask`s–the protocol guarantees they function the same way!
 
### Tips:
 
To uncomment a line use the hotkey `command /` when with your cursor on the desire line(s)
*/
var mutableTask: Task = ClassTask(name: "Ideate", completed: false, requiredRoles: Role.allCases, assignedMembers: nil)
let immutableTask: Task = ClassTask(name: "Form Group", completed: false, requiredRoles: Role.allCases, assignedMembers: nil)

/*:
## Part B
Try assigning another task to both `immutableTask` and `mutableTask`–you can assign them to each other.
Make sure to comment out the lines again for Part B–do not delete them!
### Tips:
* To uncomment a line use the hotkey `command /` when with your cursor on the desire line(s)
* Since our `Role` enum conforms to CaseIterable, you have access to the `allCases` property, which is a list of all the roles!
*/

//immutableTask = mutableTask
//mutableTask = immutableTask

/**  ``Question Response``
    *  What happened and why?
    *  When assigning `mutableTask` to `immutableTask`, an error was raised: "Cannot assign to value: 'immutableTask' is a 'let' constant." That's because 'let' creates a constant, which is immutable; 'var' creates a variable, which is mutable. Because `immutableTask` was created by 'let', we cannot modify it because it is immutable.
*/
/*:
## Part C:
Set the mutable task's `completed` field to `true`.
*/
mutableTask.completed = true

//:### Our first Test Case!

TestManager.runTests(tests: TestManager.part1Tests(mutableTask: mutableTask, immutableTask: immutableTask), name: "Section 1")

/*:
# Part 2–Arrays
Time to get comfortable with Arrays in Swift. Do all work in the corresponding functions.

## Part A–Creation
Create a list with the mutable and immutable task (in that order).
*/

func part2A() -> [Task] {
    return [mutableTask, immutableTask]
}
var tasks = part2A()

/*:
## Part B–Appending
Write a function that takes in a new task and adds the `newTask` to the list
*/

func part2B(tasks: [Task], newTask: Task) -> [Task] {
    var tasks = tasks // Function arguments are immutable by default, so this is one way to make them mutable–another method is using the `inout`, which you can feel free to look up, but is beyond the scope of this course and assignment
    tasks.append(newTask)
    return tasks
}
tasks = part2B(tasks: tasks, newTask: StructTask(name: "Start developing", requiredRoles: Role.allCases))

/*:
## Part C–Removal
Remove the first and last tasks in the list
 
Hint: To get the length of a list, do list.count
*/

func part2C(tasks: [Task]) -> [Task] {
    var tasks = tasks
    tasks.remove(at: 0)
    tasks.removeLast()
    return tasks
}

let removedTasks = part2C(tasks: tasks)

/*:
## Part D–Concatenation
*Add* two lists together
*/

// Remember that the wildcard here just allows us to call the function without
// including the parameter names. The user doesn't need to distinguish between
// the two lists, so why not make them anonymous
func part2D(_ tasks1: [Task], _ tasks2: [Task]) -> [Task] {
    return tasks1 + tasks2
}

let concatenatedList: [Task] = { // This may look scary, but it's only to keep the playground from crashing when you haven't gotten to this part yet.
    if tasks.count >= 2 {
        return part2D(removedTasks, [tasks[0], tasks[2]])
    } else {
        return []
    }
}()

TestManager.runTests(tests: TestManager.part2Tests(part2A, part2B, part2C, part2D), name: "Section 2")

/*:
## Part 3–Functions
You've already gotten familiar with functions through the last few parts, but here's some more practice.

## Function Declarations
Write a function that takes in a task and completion status and returns if the task has that status:
 *   { some task... completed: true }, true -> true
 *   { some task... completed: false }, true -> false
 *   { some task... completed: true }, false -> false
 *   { some task... completed: false }, false -> true

**It does not have to be anonymous**–but it can be :)

Once you have written this function, assign it to the variable filterFunction of type `((Task, Bool) -> (Bool))!`
 */

// Write your function here
func set_status(task: Task, completed: Bool) -> Bool {
    return task.completed == completed
}

/*:
 Hint: use autocomplete to handle the syntax.
 If autocomplete is broken for you, you can pass your function with the syntax
 `<function name>(<param1>: <param2>:)`
 So for example, `func satisfies(task: ..., completed: ...)` becomes `satisfies(task:completed:)`
 */
var filterFunction: ((Task, Bool) -> Bool)? = set_status

/*:
 What you see below is **beyond the scope of this class**.
 For those _uninterested_, all you need to know is that we took your function
 and used it to create to two functions, `completedTasks` and `incompleteTasks`
 that take in a list of tasks and return the completed or incomplete tasks respectively.
 
 For those who are _interested_–especially if you have taken or will take 3110,
 We essentially Curry your function i.e. do partial application of your function.  To see how to do this
 see `curryFunction`. Specifically, we apply the bool, and return a function which will apply the task.
 It takes in the partial application, applies it in the proper location,
 and then manages the remaining parameters. You will notice that this is more flexible than
 OCaml because it allows you to apply parameters that aren't first, but is a bit more cumbersome.
 */

let curryFunction: (Bool) -> ((Task) -> Bool) = {
    status in {
        task in return filterFunction!(task, status)
    }
}
let isCompleted = curryFunction(true)
let isIncomplete = curryFunction(false)
let completedTasksFilter: ([Task]) -> [Task] = {
    tasks in tasks.filter({ task in isCompleted(task) })
}
let incompleteTasksFilter: ([Task]) -> [Task] = {
    tasks in tasks.filter({ task in isIncomplete(task) })
}

if let _ = filterFunction {
    TestManager.runTests(tests: TestManager.part3Tests(isCompleted, isIncomplete), name: "Section 3")
} else {
    print("Has not implemented Part 3")
}

/*:
# Part 4–Loops
In this part we will be rebuilding `incompleteTasks` from scratch.
Can you tell that I like anonymous functions?

## remainingTasks
Create a function that takes in a list of tasks and returns only the tasks that are incomplete
*/
func check_completed (tasks: [Task]) -> [Task] {
    var result : [Task] = []
    for i in tasks {
        if !i.completed{
            result.append(i)
        }
    }
    return result
}

TestManager.runTests(tests: TestManager.part4Tests(check_completed), name: "Section 4")
/*:
# Part 5–Optionals and Dictionaries
Surprise! You get your instructors as group members and we started some tasks! Lucky you!
*/
let Noah = Member(name: "Noah Pikielny", netid: "np299", role: .Backend)
let Justin = Member(name: "Justin Ngai", netid: "jn537", role: .iOS)

let deployTask = StructTask(name: "Deploy", requiredRoles: [.Backend], assignedMembers: [Noah])
let frontendTask = StructTask(name: "Start Frontend", requiredRoles: [.iOS], assignedMembers: [Justin])
let marketTask = StructTask(name: "Market App", requiredRoles: [])

let memberSpecificTasks = [deployTask, frontendTask, marketTask]
/*:
# Part A–Unwrapping
Create a function that returns if a task has assigned members

Notice that `deployTask` and `frontEnd` tasks have assigned members, whereas `marketTask` has no one :/

Keep in mind that for a task to have no members, it can either have `assignedMembers` set to `nil` or [].
*/

func part5A(task: Task) -> Bool {
    guard let _ = task.assignedMembers else { //was "empty"
        return false
    }
    if task.assignedMembers!.isEmpty {
        return false
    }
    return true
}

/*:
# Part B–Dictionaries
Write a function the iterates through a list of tasks and returns a dictionary with keys being `Role` and values being `[Task]`
 
If a task has multiple require roles, add it to all of them.
 
If a role [r] has no associated tasks, the result[r] should be nil
 
It makes sense to organize our tasks by role, since members will want to see what tasks they need to do.
 
Remember when getting values from a dictionary, they will be optional so you will need to use some kind of unwrapping
 */

func part5B(tasks: [Task]) -> [Role: [Task]] {
    var result = [Role: [Task]]()
    var keys = [Role]()
    for i in tasks {
        if i.requiredRoles.count != 0 {
            for x in i.requiredRoles{
                if !keys.contains(x) {
                    keys.append(x)
                }
            }
        }
    }
    for i in keys {
        result[i] = [Task]()
    }
    for i in tasks {
        let roles : [Role] = i.requiredRoles
        if i.requiredRoles.count != 0 {
            for x in roles {
                result[x]! += [i]
            }
        }
    }
    return result
}


TestManager.runTests(tests: TestManager.part5Tests(part5A, part5B), name: "Section 5")

/*:
# Part 6–Enums and Switches
Write a function that, given a member. will tell them a message.
 
 * `iOS` → `"Hello, <insert name>!  Have a nice day :)"`
 * `Backend` → `"Hello, <insert name>! Get to work!"`
 * `Marketing` → `"Hello, <insert name>... Do whatever it is that you need to do."`
 *  Everything else → `"Hello <insert name>! Consider switching to iOS"`
**You must use a `Switch` statement for this**
*/

func part6(member: Member) -> String {
    switch member.role {
    case .iOS:
        return "Hello, \(member.name)! Have a nice day :)"
    case .Backend:
        return "Hello, \(member.name)! Get to work!"
    case .Marketing:
        return "Hello, \(member.name)... Do whatever it is that you need to do."
    case .Design, .Android:
        return  "Hello \(member.name)! Consider switching to iOS"
    }
}

TestManager.runTests(tests: TestManager.part6Tests(part6), name: "Section 6")
/*:
# Part 7–Reference Vs. Value Types
You'll notice something strange with the variables `referencingTaskType` and `valueTaskType`. What does that `.Type` mean in their type?!
**This is beyond the scope of this class**–but it is good to know when working with protocols
 
TLDR: We are storing types in these variables that conform to Task. We will use these types to conduct a set of tests and they will pass if
you input the correct answers. You must keep the `.self` after your type for this to work.
 
Here's the longer version:
Task is a protocol, which means that it describes types, or another way of thinking about it is that lays out a set of constraints
that other types will have to satisfy. When we say a variable has type `Task`, that means it is a value / object / instance
of some type that conforms to the rules set forth in Task. As you will soon see, when working with protocols, it is good to know the actual
implementation.
Since we are storing an implementation of Task in our variables, we can use them to create instances of those types!
Okay great, so why are we doing this?
There are two way of copying data when programming–you'll have to think about this quite a bit more if you take 3110–
but either you are copying data or you're copying pointers to data. This has ~very~ important ramifications that we will explore in the
testing functions that you will see below.
 
 These functions will take an implementation either StructTask or ClassTask (based off of what you assign to the variables) and will run some
 tests on the types. If you assigned the right implementation, it should pass! Try to understand what's going on and why.
 */

// We made these optional to avoid errors–ignore this,
// but do appreciate how nice guard statements are

var referencingTaskType: Task.Type? = ClassTask.self
var valueTaskType: Task.Type? = StructTask.self

func isReferenceType(_ reference: Task.Type?) {
    guard let reference = reference else { return }
    var initialTask = reference.init( // I split this init up, as per convention, because this was a very long initializer.
        name: "Check Reference Type",
        completed: false,
        requiredRoles: [],
        assignedMembers: nil
    )
    let secondaryTask = initialTask
    initialTask.completed = true
    
    assert(secondaryTask.completed)
}
isReferenceType(referencingTaskType)


func isValueType(_ value: Task.Type?) {
    guard let value = value else { return }
    var initialTask = value.init(
        name: "Check Value Type",
        completed: false,
        requiredRoles: [],
        assignedMembers: nil
    )
    let secondaryTask = initialTask
    initialTask.completed = true
    
    assert(!secondaryTask.completed) // The `!` or bang unary operator is the way we write `not` in Swift
}
isValueType(valueTaskType)
print("All Section 7 Test Passed")

/*:
# Extra Credit-Design
 
 Below is a protocol for group. Implement it as well as the equality function for Task.
 
 Afterwards assign your implementation to `groupImplementation` for testing.
 
# Extra Credit Part II
 
 In your implementation of Group, use variable properties to encapsulate your tasks!
 
 Save all of your tasks in a tasks variable and hide it from users. Do so with the private keyword like this:
 `private var tasks: [Task]`
 
 Then, instead of storing any data in completedTasks and incompleteTasks,
 
 store changes in Tasks and set any according tasks to proper completion status
 
 Some helpful reminders:
 * The `Set` variable property has a `newValue` property
 * An array has a `first(where: )` function
 * Use filters for gets.
 */

// If two tasks have the same name then they are the same.
func == (_ lhs: Task, _ rhs: Task) -> Bool {
    return lhs.name == rhs.name
}

/**
 ```
 protocol Group {
     
     var members: [Member] { get }
     
     var completedTasks: [Task] { get set }
     var incompleteTasks: [Task] { get set }
     
     init(members: [Member], tasks: [Task]) // You cannot assume these tasks are incomplete.
 }
 ```
 */

var groupImplementation: Group.Type? // = <Insert Implementation>.self
let attemptedExtraCredit = false // Mark sure to set this correctly because we will grade off of it
let attemptedExtraCreditPtII = false // Make sure this one is right too

if let groupImplementation = groupImplementation, attemptedExtraCredit {
    TestManager.runTests(tests: TestManager.part8Tests(groupImplementation, extraCredit: attemptedExtraCreditPtII), name: "Section 8")
} else {
    print("Extra Credit Not Attempted")
}
